import 'package:flutter/material.dart';

void main() => runApp(const KhalifsonApp());

const brandGreen = Color(0xFF07852D);
const darkGreen = Color(0xFF00551D);
const paleGreen = Color(0xFFE7F7EC);

class KhalifsonApp extends StatelessWidget {
  const KhalifsonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KHALIFSON DATA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brandGreen),
        scaffoldBackgroundColor: const Color(0xFFF7FAF8),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController();

  @override
  void dispose() {
    phone.dispose();
    super.dispose();
  }

  void login() {
    if (phone.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Da fatan za a shigar da lambar waya mai inganci.')),
      );
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => HomePage(phoneNumber: phone.text.trim())),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [darkGreen, brandGreen, Color(0xFFBDECCB)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const Icon(Icons.signal_cellular_alt_rounded, color: Colors.white, size: 76),
                  const SizedBox(height: 8),
                  const Text('KHALIFSON', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  const Text('DATA', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w900, letterSpacing: 4)),
                  const Text('Buy Data • Top Up • Pay Bills', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 44),
                  Card(
                    elevation: 8,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text('Login to your account', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: darkGreen)),
                          const SizedBox(height: 22),
                          TextField(
                            controller: phone,
                            keyboardType: TextInputType.phone,
                            maxLength: 14,
                            decoration: InputDecoration(
                              counterText: '',
                              prefixIcon: const Icon(Icons.phone_android),
                              hintText: 'Phone Number',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                          ),
                          const SizedBox(height: 18),
                          FilledButton(
                            onPressed: login,
                            style: FilledButton.styleFrom(
                              backgroundColor: brandGreen,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            child: const Text('Continue', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 14),
                          const Text('Demo preview only — phone verification will be connected before launch.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text('✓  Fast  •  Secure  •  Reliable', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String phoneNumber;
  const HomePage({super.key, required this.phoneNumber});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String network = 'MTN';
  String plan = '1 GB';
  int selectedIndex = 0;

  final networks = const [
    ('MTN', Color(0xFFFFC928), Icons.sim_card),
    ('Airtel', Color(0xFFE53935), Icons.sim_card),
    ('Glo', Color(0xFF159447), Icons.sim_card),
    ('9mobile', Color(0xFF176B42), Icons.sim_card),
  ];
  final plans = const [('1 GB', '₦600'), ('2 GB', '₦1,100'), ('5 GB', '₦2,700'), ('10 GB', '₦5,200')];

  void buy() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Demo ne kawai. Za a kunna sayen data bayan haɗa VTU API da biyan kuɗi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: darkGreen,
        foregroundColor: Colors.white,
        title: const Text('KHALIFSON DATA', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [brandGreen, darkGreen]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Row(
              children: [
                const Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 42),
                const SizedBox(width: 14),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Wallet Balance', style: TextStyle(color: Colors.white70)),
                  Text('₦0.00', style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.w900)),
                ])),
                FilledButton.tonal(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('Fund Wallet'), content: Text('Za a haɗa hanyoyin biyan kuɗi kafin amfani da wallet na gaske.'))), child: const Text('Top Up +')),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const SectionTitle('Buy Data'),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: networks.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .88),
            itemBuilder: (context, i) {
              final item = networks[i];
              final active = network == item.$1;
              return InkWell(
                onTap: () => setState(() => network = item.$1),
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  decoration: BoxDecoration(color: active ? paleGreen : Colors.white, border: Border.all(color: active ? brandGreen : Colors.black12, width: active ? 2 : 1), borderRadius: BorderRadius.circular(16)),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(item.$3, size: 30, color: item.$2),
                    const SizedBox(height: 6),
                    FittedBox(child: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.bold))),
                  ]),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          const SectionTitle('Select Data Plan'),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: plans.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 2.4),
            itemBuilder: (context, i) {
              final p = plans[i];
              final active = plan == p.$1;
              return InkWell(
                onTap: () => setState(() => plan = p.$1),
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  decoration: BoxDecoration(color: active ? paleGreen : Colors.white, border: Border.all(color: active ? brandGreen : Colors.black12, width: active ? 2 : 1), borderRadius: BorderRadius.circular(14)),
                  child: Center(child: Text('${p.$1}   ${p.$2}', style: const TextStyle(fontWeight: FontWeight.bold))),
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: buy,
            icon: const Icon(Icons.bolt),
            label: const Text('Buy Now'),
            style: FilledButton.styleFrom(backgroundColor: brandGreen, padding: const EdgeInsets.symmetric(vertical: 17), textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 24),
          const SectionTitle('More Services'),
          const SizedBox(height: 10),
          const Row(children: [
            Expanded(child: ServiceTile(icon: Icons.phone_android, label: 'Airtime Top-Up')),
            Expanded(child: ServiceTile(icon: Icons.receipt_long, label: 'Transaction History')),
            Expanded(child: ServiceTile(icon: Icons.person_outline, label: 'My Profile')),
          ]),
          const SizedBox(height: 12),
          Text('Logged in as ${widget.phoneNumber}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (i) => setState(() => selectedIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.support_agent), label: 'Support'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: darkGreen));
}

class ServiceTile extends StatelessWidget {
  final IconData icon;
  final String label;
  const ServiceTile({super.key, required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 6),
      child: Column(children: [Icon(icon, color: brandGreen, size: 28), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))]),
    ),
  );
}
